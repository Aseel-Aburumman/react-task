declare module 'aos';
